﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","tt",{title:"Интерфейс төсләрен сайлау",preview:"Тере карап алу",config:"Бу юлны config.js файлына языгыз",predefined:"Баштан билгеләнгән төсләр җыелмасы"});